import { FontFlux } from 'font-flux-js';
import {
    getGlyphrStudioApp,
    getProjectEditorImportTarget,
    setCurrentProjectEditor,
} from '../../app/main.js';
import { updateProgressIndicator } from '../../controls/progress-indicator/progress_indicator.js';
import { sortCharacterRanges } from '../../pages/settings_project.js';
import { Glyph } from '../../project_data/glyph.js';
import { ProjectEditor } from '../../project_editor/project_editor.js';
import { ioSVG_convertSVGTagsToGlyph } from '../svg_outlines/svg_outline_import.js';
import { importGlyphs } from './tables/glyphs.js';
import { importGposKernPairs } from './tables/gpos.js';
import { importLigatures } from './tables/gsub.js';
import { importTable_head } from './tables/head.js';
import { importTable_name } from './tables/name.js';
import { importTable_os2 } from './tables/os2.js';
import { importTable_post } from './tables/post.js';

/**
 * Extracts ligature data from the GSUB table
 * @param {Object} importedFont - FontFlux font object
 * @returns {Array} - Array of ligature objects {by: glyphIndex, sub: [glyphIndex1, glyphIndex2, ...]}
 */
function extractLigaturesFromGSUB(importedFont) {
	const ligatures = [];

	if (!importedFont.features?.GSUB?.lookupList?.lookups) {
		return ligatures;
	}

	const lookups = importedFont.features.GSUB.lookupList.lookups;

	// Find ligature lookups (type 4)
	for (const lookup of lookups) {
		if (lookup.lookupType === 4) { // Ligature substitution
			for (const subtable of lookup.subtables) {
				// Process each ligature set
				for (const ligatureSet of subtable.ligatureSets) {
					for (const ligature of ligatureSet) {
						if (ligature.componentGlyphIDs && ligature.ligatureGlyph !== undefined) {
							ligatures.push({
								by: ligature.ligatureGlyph,
								sub: ligature.componentGlyphIDs
							});
						}
					}
				}
			}
		}
	}

	return ligatures;
}
let importItemCounter = 0;
let importItemTotal = 0;

/**
 * Takes the import result from Font Flux JS, reads the data, and
 * creates a new Glyphr Studio Project from it.
 * @param {Object} importedFont - result from Font Flux JS import
 * @param {Boolean} testing - is this a vitest test
 * @returns nothing
 */
export async function ioFont_importFont(importedFont, testing = false) {
	if (!testing) console.log(importedFont);
	const editor = testing ? new ProjectEditor() : getProjectEditorImportTarget();
	const project = editor.project;

	// Reset module data
	importItemCounter = 0;
	importItemTotal = 0;

	// --------------------------------------------------------------
	// Set up import groups
	// --------------------------------------------------------------

	const fontGlyphs = importedFont.glyphs || {};
	// log(`\nfontGlyphs:`);
	// log(fontGlyphs);
	const fontLigatures = extractLigaturesFromGSUB(importedFont) || [];
	// log(`\nfontLigatures:`);
	// log(fontLigatures);
	const gposKernTables = importedFont.kerning || [];
	// log(`\n⮟kernTables⮟`);
	// log(gposKernTables);

	// --------------------------------------------------------------
	// Count items and set up progress indicator
	// --------------------------------------------------------------

	let kernPairCount = 0;
	const loadedGposKernTables = [];
	// For FontFlux, kerning is already a simple array
	// gposKernTables.forEach((table) => {
	// 	const tableData = loadOneKernTable(table);
	// 	loadedGposKernTables.push(tableData.subtables);
	// 	kernPairCount += tableData.kernPairCount;
	// });
	kernPairCount = gposKernTables.length;
	importItemTotal = fontGlyphs.length + fontLigatures.length + kernPairCount;

	// --------------------------------------------------------------
	// Import data
	// --------------------------------------------------------------

	// Characters
	project.glyphs = await importGlyphs(fontGlyphs, project);

	// Ligatures
	project.ligatures = await importLigatures(importedFont, fontLigatures);

	// Kern data
	project.kerning = await importGposKernPairs(importedFont, gposKernTables);

	// Metadata
	importTable_head(importedFont, project);
	importTable_name(importedFont, project);
	importTable_os2(importedFont, project);
	importTable_post(importedFont, project);

	// --------------------------------------------------------------
	// Finish up
	// --------------------------------------------------------------

	// log(editor);
	if (testing) {
		return editor.project;
	} else {
		setCurrentProjectEditor(editor);
		editor.project.resetSessionStateForAllItems();
		sortCharacterRanges();
		editor.nav.page = 'Overview';
		const app = getGlyphrStudioApp();
		app.selectedProjectEditor = editor;
		app.selectedProjectEditor.navigate();
	}
}

/**
 * Converts one FontFlux Glyph into a Glyphr Studio Glyph.
 * Used for characters and ligatures.
 * @param {Object} glyph - FontFlux Glyph object
 * @returns {Glyph}
 */
export function makeGlyphrStudioGlyphObject(glyph) {
	// log(`makeGlyphrStudioGlyphObject`, 'start');
	// log(glyph);
	const advance = glyph.advanceWidth;
	// log(`advance: ${advance}`);

	// Import Path Data
	let data;
	if (glyph.contours) {
		data = FontFlux.contoursToSVG(glyph.contours);
	}
	// log('Glyph has SVG data');
	// log(data);

	let importedGlyph;

	if (data) {
		importedGlyph = ioSVG_convertSVGTagsToGlyph(`<svg><path d="${data}"/></svg>`, false);
		// log(`importedGlyph`);
		// log(importedGlyph);
	} else {
		importedGlyph = new Glyph();
	}

	if (importedGlyph) {
		importedGlyph.advanceWidth = advance;
		// importedGlyph.flipNS();
	}

	// log(`makeGlyphrStudioGlyphObject`, 'end');
	return importedGlyph;
}

// --------------------------------------------------------------
// Progress Indicator
// --------------------------------------------------------------

/**
 * Updates the progress indicator UI
 * @param {String} type - Character, Ligature, Kern Pair
 */
export async function updateFontImportProgressIndicator(type) {
	await updateProgressIndicator(`
			<span class="progress-indicator__title">Importing ${type}s</span>
			Item
			<span class="progress-indicator__counter">${importItemCounter}</span>
			 of
			<span class="progress-indicator__counter">${importItemTotal}</span>
		`);
}

export function decrementItemTotal() {
	importItemTotal--;
}

export function incrementItemCounter() {
	importItemCounter++;
}
